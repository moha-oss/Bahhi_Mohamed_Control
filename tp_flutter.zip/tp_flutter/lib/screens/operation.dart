import 'package:flutter/material.dart';

class Operation extends StatefulWidget {
  State<Operation> createState() => _OperationState();
}

class _OperationState extends State<Operation> {
  final nb1 = TextEditingController();
  final nb2 = TextEditingController();

  final f1 = GlobalKey<FormState>();
  final f2 = GlobalKey<FormState>();

  double total = 0.0;
  String msg = "";
  String selectedOperation = "+";

  void calculate() {
    if (nb1.text.isEmpty || nb2.text.isEmpty) {
      setState(() {
        msg = "Erreur, les champs sont vides !!";
      });
    } else {
      double num1 = double.parse(nb1.text);
      double num2 = double.parse(nb2.text);

      setState(() {
        if (selectedOperation == "+") {
          total = num1 + num2;
        } else if (selectedOperation == "-") {
          total = num1 - num2;
        } else if (selectedOperation == "*") {
          total = num1 * num2;
        } else if (selectedOperation == "/") {
          if (num2 != 0) {
            total = num1 / num2;
          } else {
            msg = "Erreur, division par zéro !!";
          }
        }
        nb1.text = "";
        nb2.text = "";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context),
      child: Scaffold(
        appBar: AppBar(
          title: Text("Operation"),
        ),
        body: Center(
          child: Column(
            children: [
              Text(
                "CALCULATOR",
                style: TextStyle(fontSize: 30, color: Colors.black54),
              ),
              SizedBox(height: 10),
              Padding(
                padding: EdgeInsets.all(8.0),
                child: Form(
                  key: f1,
                  child: TextFormField(
                    controller: nb1,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter first number',
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Padding(
                padding: EdgeInsets.all(8.0),
                child: Form(
                  key: f2,
                  child: TextFormField(
                    controller: nb2,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter second number',
                    ),
                  ),
                ),
              ),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Radio<String>(
                    value: "+",
                    groupValue: selectedOperation,
                    onChanged: (value) {
                      setState(() {
                        selectedOperation = value!;
                      });
                    },
                  ),
                  Text("+"),
                  Radio<String>(
                    value: "-",
                    groupValue: selectedOperation,
                    onChanged: (value) {
                      setState(() {
                        selectedOperation = value!;
                      });
                    },
                  ),
                  Text("-"),
                  Radio<String>(
                    value: "*",
                    groupValue: selectedOperation,
                    onChanged: (value) {
                      setState(() {
                        selectedOperation = value!;
                      });
                    },
                  ),
                  Text("*"),
                  Radio<String>(
                    value: "/",
                    groupValue: selectedOperation,
                    onChanged: (value) {
                      setState(() {
                        selectedOperation = value!;
                      });
                    },
                  ),
                  Text("/"),
                ],
              ),
              ElevatedButton(
                onPressed: () {
                  calculate();
                },
                child: Text("Calculate"),
                style: ButtonStyle(
                  backgroundColor:
                      MaterialStateProperty.all<Color>(Colors.black54),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Text("Total: "),
                  Text(
                    total.toString(),
                    style: TextStyle(
                        fontSize: 20,
                        color: const Color.fromARGB(255, 231, 244, 54)),
                  ),
                ],
              ),
              Text(
                msg,
                style: TextStyle(
                    fontSize: 20,
                    color: const Color.fromARGB(255, 231, 244, 54)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
