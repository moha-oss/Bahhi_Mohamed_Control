import 'package:flutter/material.dart';
import 'package:tp_flutter/screens/operation.dart';
import 'package:tp_flutter/screens/conjugaison.dart';
import 'package:tp_flutter/screens/drawer.dart';

class Home extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("CALCUL & CONJUGAISON"),
        actions: [
          PopupMenuButton<String>(
            itemBuilder: (_) => [
              PopupMenuItem(
                child: Text("Operation"),
                value: "operation",
              ),
              PopupMenuItem(
                child: Text("Conjugaison"),
                value: "conjugaison",
              ),
            ],
            onSelected: (value) {
              if (value == "operation") {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Operation()),
                );
              } else if (value == "conjugaison") {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ConjugaisonScreen()),
                );
              }
            },
          ),
        ],
      ),
      body: Center(
        child: Text("body"),
      ),
      drawer: CustomDrawer(),
    );
  }
}
