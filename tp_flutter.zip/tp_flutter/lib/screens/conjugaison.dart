import 'package:flutter/material.dart';

class ConjugaisonScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context),
      child: Scaffold(
        appBar: AppBar(
          title: Text("Conjugaison"),
        ),
        body: Center(
          child: Column(
            children: [
              Text(
                "Conjugaison des verbes du 1er groupe",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              ConjugationForm(),
            ],
          ),
        ),
      ),
    );
  }
}

class ConjugationForm extends StatefulWidget {
  @override
  _ConjugationFormState createState() => _ConjugationFormState();
}

class _ConjugationFormState extends State<ConjugationForm> {
  final TextEditingController _verbController = TextEditingController();
  String _conjugatedVerb = '';

  void conjugateVerb() {
    final verb = _verbController.text.trim();

    if (verb.endsWith('er')) {
      final rootVerb = verb.substring(0, verb.length - 2);
      String firstPersonSingular = 'je';

      if (['a', 'e', 'i', 'o', 'u'].contains(rootVerb[0])) {
        firstPersonSingular = "j'";
      }

      setState(() {
        _conjugatedVerb = '''
      $firstPersonSingular ${rootVerb}e
      tu ${rootVerb}es
      il ${rootVerb}e
      nous ${rootVerb}ons
      vous ${rootVerb}ez
      ils ${rootVerb}ent
    ''';
      });
    } else {
      setState(() {
        _conjugatedVerb = "Le verbe n'est pas du 1er groupe.";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextField(
            controller: _verbController,
            decoration: InputDecoration(
              labelText: "Entrez un verbe du 1er groupe",
            ),
          ),
          SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: conjugateVerb,
            child: Text("Conjuguer"),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.black54),
            ),
          ),
          SizedBox(height: 16.0),
          Text(
            _conjugatedVerb,
            style: TextStyle(fontSize: 16.0),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _verbController.dispose();
    super.dispose();
  }
}
