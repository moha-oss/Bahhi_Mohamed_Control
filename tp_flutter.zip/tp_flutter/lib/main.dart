import 'package:flutter/material.dart';
import 'package:tp_flutter/screens/operation.dart';
import 'package:tp_flutter/screens/home.dart';

void main() {
  runApp(F1());
}

class F1 extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "APPLICATION",
      home: Home(),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.black54,
        appBarTheme: AppBarTheme(
          color: Colors.black54,
        ),
        buttonTheme: ButtonThemeData(
          buttonColor: Colors.black54,
          textTheme: ButtonTextTheme.primary,
        ),
      ),
    );
  }
}
