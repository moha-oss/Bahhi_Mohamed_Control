import 'package:flutter/material.dart';
import 'package:tp_flutter/screens/operation.dart';
import 'package:tp_flutter/screens/conjugaison.dart';

class CustomDrawer extends StatelessWidget {
  void navigateToMessage(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (context) {
      return Operation();
    }));
  }

  void navigateToOperations(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (context) {
      return Operation();
    }));
  }

  void navigateToConjugaison(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (context) {
      return ConjugaisonScreen();
    }));
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          AppBar(
            title: Text("MENU"),
          ),
          ListTile(
            title: Text("Operations"),
            leading: Icon(Icons.calculate),
            onTap: () {
              navigateToOperations(context);
            },
          ),
          ListTile(
            title: Text("Conjugaison"),
            leading: Icon(Icons.format_list_numbered),
            onTap: () {
              navigateToConjugaison(context);
            },
          ),
        ],
      ),
    );
  }
}
